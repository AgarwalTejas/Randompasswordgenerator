import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk
import random
import string
import pyperclip

def calculate_strength(pwd):
    length_score = min(len(pwd) / 12, 1)
    variety = len(set([
        any(c.islower() for c in pwd),
        any(c.isupper() for c in pwd),
        any(c.isdigit() for c in pwd),
        any(c in string.punctuation for c in pwd)
    ]))
    score = length_score * 0.5 + (variety / 4) * 0.5
    if score < 0.4:
        return "Weak", "red"
    elif score < 0.75:
        return "Moderate", "orange"
    else:
        return "Strong", "green"

def generate_password():
    try:
        length = int(length_var.get())
        if length < 4:
            messagebox.showerror("Error", "Password length must be at least 4")
            return
    except ValueError:
        messagebox.showerror("Error", "Please enter a valid number for length")
        return

    charset = ""
    if var_upper.get(): charset += string.ascii_uppercase
    if var_lower.get(): charset += string.ascii_lowercase
    if var_digits.get(): charset += string.digits
    if var_symbols.get(): charset += string.punctuation

    for ch in exclude_var.get():
        charset = charset.replace(ch, "")

    if not charset:
        messagebox.showerror("Error", "Select at least one character type")
        return

    password = "".join(random.choice(charset) for _ in range(length))
    password_var.set(password)
    strength, color = calculate_strength(password)
    strength_label.config(text=f"Strength: {strength}", fg=color)

def copy_to_clipboard():
    pyperclip.copy(password_var.get())
    messagebox.showinfo("Copied", "Password copied to clipboard!")

def toggle_password():
    show = "*" if password_entry.cget("show") == "" else ""
    password_entry.config(show=show)
    toggle_btn.config(text="👁️" if show == "" else "🙈")

def exit_fullscreen(event=None):
    root.attributes("-fullscreen", False)

# Setup Window
root = tk.Tk()
root.title("🔐 Fullscreen Password Generator")
root.attributes("-fullscreen", True)
root.bind("<Escape>", exit_fullscreen)

screen_width = root.winfo_screenwidth()
screen_height = root.winfo_screenheight()

# Background Image
bg_img = Image.open("background.png").resize((screen_width, screen_height))
bg_photo = ImageTk.PhotoImage(bg_img)

canvas = tk.Canvas(root, width=screen_width, height=screen_height)
canvas.pack(fill="both", expand=True)
canvas.create_image(0, 0, image=bg_photo, anchor="nw")

# UI Frame
frame = tk.Frame(root, bg="#ffffff", bd=3)
frame.place(relx=0.5, rely=0.5, anchor="center")

tk.Label(frame, text="Advanced Password Generator", font=("Segoe UI", 22, "bold"), bg="white").grid(row=0, columnspan=3, pady=10)

tk.Label(frame, text="Password Length:", bg="white").grid(row=1, column=0, sticky="w", padx=10)
length_var = tk.StringVar(value="12")
tk.Entry(frame, textvariable=length_var, width=6).grid(row=1, column=1, sticky="w")

var_upper = tk.BooleanVar(value=True)
tk.Checkbutton(frame, text="Uppercase", variable=var_upper, bg="white").grid(row=2, column=0, sticky="w", padx=10)
var_lower = tk.BooleanVar(value=True)
tk.Checkbutton(frame, text="Lowercase", variable=var_lower, bg="white").grid(row=2, column=1, sticky="w")
var_digits = tk.BooleanVar(value=True)
tk.Checkbutton(frame, text="Numbers", variable=var_digits, bg="white").grid(row=3, column=0, sticky="w", padx=10)
var_symbols = tk.BooleanVar(value=False)
tk.Checkbutton(frame, text="Symbols", variable=var_symbols, bg="white").grid(row=3, column=1, sticky="w")

tk.Label(frame, text="Exclude Characters:", bg="white").grid(row=4, column=0, sticky="w", padx=10)
exclude_var = tk.StringVar()
tk.Entry(frame, textvariable=exclude_var, width=20).grid(row=4, column=1, sticky="w")

tk.Button(frame, text="Generate Password", command=generate_password, bg="#4CAF50", fg="white").grid(row=5, column=0, columnspan=2, pady=10)

password_var = tk.StringVar()
password_entry = tk.Entry(frame, textvariable=password_var, width=30, font=("Courier", 12), show="")
password_entry.grid(row=6, column=0, columnspan=2, padx=10)

toggle_btn = tk.Button(frame, text="🙈", command=toggle_password, bg="white")
toggle_btn.grid(row=6, column=2)

tk.Button(frame, text="Copy to Clipboard", command=copy_to_clipboard, bg="#2196F3", fg="white").grid(row=7, column=0, columnspan=3, pady=10)

strength_label = tk.Label(frame, text="", font=("Segoe UI", 10), bg="white")
strength_label.grid(row=8, column=0, columnspan=3, pady=5)

root.mainloop()